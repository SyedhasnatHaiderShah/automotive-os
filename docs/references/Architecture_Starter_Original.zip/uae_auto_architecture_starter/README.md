# UAE Automotive Marketplace + Dealer SaaS — engineering design starter

Prepared from the existing FRD v2.1 product baseline. **Design artifacts, not an operational backend or ready-made product.**

## Included

- `docs/ARCHITECTURE.md` — component design, domain boundaries, multi-tenancy and data flows.
- `docs/API_CONTRACTS.md` — first draft REST API surface, example request/response payloads, security expectations.
- `docs/FRONTEND_DESIGN.md` — buyer, dealer and platform screen/route plans, design tokens and UX flows.
- `docs/SPRINT0_PLAN.md` — prioritized tasks and acceptance criteria.
- `db/schema.prisma` — MVP relational domain model draft (identity, tenants, catalog, vehicles, listings, leads, consents, appointments, billing basics).
- `db/tenant_policies.sql` — **illustrative** tenant-level Row-Level Security SQL; requires security review.
- `db/erd.mmd` — Mermaid ER diagram.
- `frontend/preview.html` — self-contained navigable interactive HTML design concept; **all sample data fictional**, actions do not contact an API.

## What this does not do yet

No production application runtime, real identity integration, database migration applied, actual vehicle media, payments, KYB integration, real customers or dealers, or robust end-to-end tests. A full production Prisma 8 implementation should pin runtime/config conventions, adapt the schema where needed, and validate migrations against a PostgreSQL instance. A database migration should never be run on production based only on this proposal.

## Important blocker

The public marketplace **must not** browse private inventory tables using a privileged database user. Build a redacted published-listing read model, robust authorization and explicit ownership policies for buyer resources. An operationally correct and secure release cannot be inferred from a working prototype UI.

## Suggested build order

1. Confirm ADRs, API DTOs, permissions and data protection baseline.
2. Create monorepo and NestJS / Next.js app shells.
3. Validate Prisma schema, create controlled migrations and RLS tests.
4. Build a single dealer-stock → reviewed-listing → buyer-enquiry → dealer-lead vertical slice.
5. Replace HTML prototype with Next.js components and real APIs; extend to full DMS modules once marketplace traction is proven.

*Working UI name AutoNexa is a placeholder and not a registered product name suggestion.*
